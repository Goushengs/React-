ConnectedCounter作为Route的component能不能用￼



这么整，dva可以和connect-react-router结合吗？￼
内置 



effect的action在哪传进去￼



sagaEffect 里除了put,call还有一些其它什么方法呢￼
吃饱了
面试都咋问呢dva￼
说滴对！
connected-react-router是不是只在dva中用了，一直感觉这个库没啥用，就是重写了路由方法￼
王木木
可以再跳转页面返回的时候记录上一次操作吧￼
