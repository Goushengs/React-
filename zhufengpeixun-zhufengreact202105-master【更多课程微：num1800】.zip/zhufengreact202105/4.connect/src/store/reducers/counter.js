function counter(state={number:0},action){
    return state;
}
export default counter;