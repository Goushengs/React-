redux  并不跟react绑定

老师，react在编译的过程中会自动的把state里的数据进行编码吗？
就是使用react就自动能避免xss攻击吗？ 能
