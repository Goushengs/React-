// @ts-nocheck
import { Plugin } from 'C:/Users/83687/AppData/Local/Yarn/Data/global/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange',],
});

export { plugin };
