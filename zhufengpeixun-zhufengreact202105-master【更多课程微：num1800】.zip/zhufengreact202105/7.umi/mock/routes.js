
export default {
    'GET /api/routes':[
        {
            path:'/foo',
            component:'Foo.js'
        }
    ]
}