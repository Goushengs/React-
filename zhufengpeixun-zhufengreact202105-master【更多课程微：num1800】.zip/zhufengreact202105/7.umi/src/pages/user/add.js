import React from 'react';
export default class Add extends React.Component{
    render(){
        return (
            <form>
                <input></input>
                <input type="submit"></input>
            </form>
        )
    }
}