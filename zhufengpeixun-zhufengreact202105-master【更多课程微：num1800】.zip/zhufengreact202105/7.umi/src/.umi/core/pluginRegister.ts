// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from 'C:/aproject/zhufengreact202105/7.umi/src/app.js';

  plugin.register({
    apply: Plugin_0,
    path: 'C:/aproject/zhufengreact202105/7.umi/src/app.js',
  });
