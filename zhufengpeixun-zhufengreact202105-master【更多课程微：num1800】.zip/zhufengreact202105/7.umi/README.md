
- 约定式路由+声明式路由
- 配置式(后面讲)



umi的定位是什么，用来开发小型的react项目吗￼
大中上都可以
流行的antdesign pro
Traveller
不配置路由的话  如果有多个layout他怎么知道用哪一个呢￼ 只能有一个
王木木
这样[id].js动态匹配是umi特有的嘛￼ 是的
特殊语法
$id
[id]

原来那个user.js呢￼
Traveller
layouts文件夹里面不是可以写多个layout吗￼
不行

wrapper文件是怎么被引用进去的。也是umi特有的引用方式吗￼


刚才那 layout,  如果某个页面不想用 layouts/index.js 呢？￼
说滴对！
能配合react-redux使用吗￼ umi+dva+antdesign=antdesignpro
Traveller
感觉还是声明式的路由好控制￼


吃饱了
真方便￼
Traveller
app.js是固定的入口文件吗￼ 定死的
哈登
这个umi的周下载量好像才2万5￼
20:56
joker
oldRender 是啥？￼

