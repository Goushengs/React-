
let obj1 = {name:'zhufeng'};
let obj2 = obj1;
console.log(obj1 === obj2);
console.log(Object.is(obj1,obj2));
