

function create(){
  console.log(arguments.slice(2));
}
create(1,2,3);