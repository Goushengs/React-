
function Person(){

}

let person = new Person();
console.log(person.constructor === Person);
