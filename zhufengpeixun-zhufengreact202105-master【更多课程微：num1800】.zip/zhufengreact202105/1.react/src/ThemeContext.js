import React from 'react';
let ThemeContext = React.createContext();
export default ThemeContext;