import React from 'react';
class NavBar extends React.Component{
  render(){
      return (
       <div>Not Found</div>
      )
  }
}
export default NavBar;