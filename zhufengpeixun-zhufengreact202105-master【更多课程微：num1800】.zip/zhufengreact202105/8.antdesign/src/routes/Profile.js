import { renderRoutes } from "../utils/routes";


function Profile(props){
    return (
        <div>
            <h2>Profile</h2>
           
        </div>
    )
}
export default Profile;