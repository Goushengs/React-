21:47
王木木
'import', {
            libraryName: 'antd',
            libraryDirectory: 'es',
            style: 'css',
        }),￼
说滴对！
dva-cli
跟umi没有关系 
dva+antdesign
感觉没用到umi啊，这不就是dva + react吗￼
嘎啦果
如果个人中心还有子路由，他会递归去渲染吗￼
