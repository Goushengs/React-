let  classnames= require('classnames');
let result = classnames({
    active:true,
    strong:false,
    highlight:true
})
console.log(result);