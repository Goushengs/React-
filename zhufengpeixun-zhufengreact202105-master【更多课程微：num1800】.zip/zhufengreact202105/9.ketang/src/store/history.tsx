import {createHashHistory} from 'history';
let history = createHashHistory();
export default history;