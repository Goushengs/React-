export default interface Slider{
    url:string;
}