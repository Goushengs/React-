export enum LOGIN_TYPES {
    UN_VALIDATE, //尚未验证
    LOGIN_SUCCESS, // 登录成功
    UN_LOGIN //未登录
}

