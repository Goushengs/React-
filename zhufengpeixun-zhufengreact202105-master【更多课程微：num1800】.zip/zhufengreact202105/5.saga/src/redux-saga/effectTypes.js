export const TAKE = 'TAKE';//监听
export const PUT = 'PUT';//派发
export const FORK = 'FORK';//fork出一个子进程
export const CALL = 'CALL';//调用一个函数，返回Promise
export const CPS = 'CPS';
export const ALL = 'ALL';
export const CANCEL = 'CANCEL';