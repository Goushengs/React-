export const ASYNC_ADD = 'ASYNC_ADD';//异步加1 发给监听saga
export const ADD = 'ADD';//加上1 发给worker saga

export const ASYNC_MINUS = 'ASYNC_MINUS';//异步减1 发给监听saga
export const MINUS = 'MINUS';//减1 发给worker saga
export const STOP = 'STOP';//减1 发给worker saga