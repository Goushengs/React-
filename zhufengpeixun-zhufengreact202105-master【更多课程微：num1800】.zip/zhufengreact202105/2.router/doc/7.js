
let str = 'a';
let reg = /a/;
console.log(str.match(reg));
console.log(reg.exec(str));
console.log(reg.test(str));