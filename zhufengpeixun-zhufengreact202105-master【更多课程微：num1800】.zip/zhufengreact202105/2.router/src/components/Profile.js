import React from 'react';

class Profile extends React.Component{
    render(){
        return <div>Profile</div>
    }
}
export default Profile;